#include <stdio.h>

#include <pthread.h>
#include <poll.h>

#include <stdlib.h>
#include <string.h>

#include <unistd.h>
#include <sys/socket.h>
#include <arpa/inet.h>


#define MAX_EVENTS 5000



#define PORT 5655

unsigned long long factorial(long long n){ 
    if( n > 20 ) {
        n = 20;
    }
    unsigned long long ans = 1;
    for (int i = 1; i <= n; i++){
        ans *= i;
    }
    return ans;
}

void *thread_func(void *sockfd) {

    int client_socket = *(int *)sockfd;
     
    int read_size;
    
    char message[1000];


    while (( read_size = recv(client_socket, message, 9000, 0 ) ) > 0) {
        message[read_size] = '\0';
        
        int num = atoi(message);
        
        long long int result = factorial(num);
        
        
        
        char result_value [5000];
        
        sprintf(result_value, "%lld", result);
        
        
        write(client_socket, result_value, strlen(result_value));
        
        
        memset(message, 0, 5000);
    }

    if ( read_size == 0 ) {  
        fflush(stdout);
    }
    close(client_socket);
    return 0;
}

int main(int argc, char *argv[]) {
    struct sockaddr_in server_addr, client_addr;
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);


    if (sockfd <= -1 ) {
    
        perror("error in socket");
        exit(EXIT_FAILURE);
    }
    printf("Socket opened ");
	
    server_addr.sin_addr.s_addr = inet_addr("10.0.2.8");
    
    
    
    server_addr.sin_family = AF_INET;
    
    server_addr.sin_port = htons(PORT);

    int bind_response = bind(sockfd, (struct sockaddr *) &server_addr, sizeof(server_addr));
    
    
    if (bind_response < 0) {
        perror("error in bind\n");
        exit(EXIT_FAILURE);
    }
    printf("Socket bound");

    int listen_response = listen(sockfd, 8000);
    
    if (listen_response < 0) {
        perror("Error on listening\n");
        exit(EXIT_FAILURE);
    }
    printf("Socket listening...");
    
    
    
    int sock_size = sizeof(struct sockaddr_in);

    struct pollfd fds[MAX_EVENTS];
    
    
    int nfds = 1;  // initialize with 1 (for the listening socket)
    
    
    fds[0].fd = sockfd;
    
    
    fds[0].events = POLLIN;

    while (1) {
        int poll_response = poll(fds, nfds, -1);
        
        
        
        if (poll_response < 0) {
 
 
            perror("poll");
 
 
            exit(EXIT_FAILURE);
 
        }

        for (int i = 0; i < nfds; i++) {
        
            if (fds[i].revents & POLLIN && fds[i].fd == sockfd) {
                
                    int client_socket = accept(sockfd, (struct sockaddr *) &client_addr, (socklen_t *) &sock_size);
 
                    if (client_socket == -1) {
 
                        perror("accept");
 
                        exit(EXIT_FAILURE);
                    }
                    if (nfds < MAX_EVENTS) {
 
                        fds[nfds].fd = client_socket;
 
                        fds[nfds].events = POLLIN;
 
                        nfds++;
                    }
                 }
              else if(fds[i].fd != sockfd && fds[i].revents & POLLIN ) {
 
                    pthread_t thread_id;
 
                    int *new_sock;
 
                    new_sock = malloc(1);
 
                    *new_sock = fds[i].fd;
 
                    if (pthread_create(&thread_id, NULL, thread_func, (void *) new_sock) < 0) {
 
                        perror("error in creating thread");
 
                        return 1;
                    }
 
                    pthread_join(thread_id, NULL);
 
 
 
 
                    fds[i].fd = -1; 
 
                }
            }
        }
    

    close(sockfd);
    return 0;
}

