#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>  
#include <sys/socket.h>  
#include <netinet/in.h>
#include <arpa/inet.h>
#include <inttypes.h>
#include <sys/select.h>
#include <sys/time.h>
#include <sys/types.h>
#include <strings.h>
#define PORT 5555
#define num_requests 50
#define num_concurrent_connections 2000

unsigned long long int factorial(int n)
{
    unsigned long long int f = 1;
    
    if (n > 20) n = 20;
    
    for (int i = 1; i <= n; i++)
    
        f *= i;
    
    return f;
}

int main(){
    int number_of_conons = 0;
    
    
    
    struct sockaddr_in server_socket;

    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    
    
    if (server_fd < 0){
    
    
        perror("Socket Creation failed");
    
        exit(1);
    
    
    }
    
    
    
    server_socket.sin_port = htons(5555);

    server_socket.sin_family = AF_INET;
    
    server_socket.sin_addr.s_addr = INADDR_ANY;





    if (bind(server_fd, (struct sockaddr*)&server_socket, sizeof(server_socket)) < 0){
     
        perror("Server bind failed");
     
     
     
        exit(1);
    }

    if (listen(server_fd, num_concurrent_connections) < 0){
     
        perror("Server listen failed");
        exit(1);
    }

    fd_set allFDs;
  
    fd_set constpdatFDs;
  
    FD_ZERO(&allFDs);
  
  
    FD_SET(server_fd, &allFDs);

    struct sockaddr_in client_socket;
    socklen_t len = sizeof(client_socket);
    while(1){
        constpdatFDs = allFDs;
        
        if (number_of_conons == num_concurrent_connections){
            break;
        }
        
        
        if (select(FD_SETSIZE, &constpdatFDs, NULL, NULL, NULL) < 0){
           
            perror("Select Failed");
           
           
            exit(1);
        }        
        for (int i = 0; i < FD_SETSIZE; i++){
            
            
            if (FD_ISSET(i, &constpdatFDs)){
                
                
                if (i != server_fd){
                   
                    char rec_buffer[1000];
                   
                   
                    bzero(rec_buffer, 1000);
                   
                   
                   
                   
                   
                   if(read(i, rec_buffer, 1000)==0){
                        FD_CLR(i, &allFDs);
                        number_of_conons = number_of_conons + 1 ;
                        continue;
                    }
                   
                   
                    if (read(i, rec_buffer, 1000) < 0){
                    
                        perror("Read Failed");
                    
                    
                    
                        exit(1);
                    }
                    
                    if(read(i, rec_buffer, 1000) > 0){
                        int value_recieved = atoi(rec_buffer);
                        unsigned long long int fact = factorial(value_recieved);
                       
                       
                        char sending_buffer[1000];
                       
                       
                        getpeername(i, (struct sockaddr*)&client_socket, &len);
                       
                       
                        snprintf(sending_buffer, 1000, "%lld", fact);
                       
                       
                        send(i, sending_buffer, 1000, 0);
                    }
                }
                else{
                    int newConnection = accept(server_fd, (struct sockaddr*)&client_socket, &len);
                   
                   
                    if (newConnection < 0){
                        perror("Accept Failed");
                   
                        exit(1);
                    }
                    
                    
                    
                    else{
                    // added a else condition
                    	FD_SET(newConnection, &allFDs);
                    }
                }
            }
        }
    }
    close(server_fd);
    return 0;
}
