#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>

void *connection_handler(void *);

unsigned long long factorial(long long n){ 
    if( n > 20 ) {
        n = 20;
   
    }
   
    unsigned long long ans = 1;
   
    for (int i = 1; i <= n; i++){
        ans *= i;
   
    }
   
    return ans;
}

void *connection_handler(void *socket_desc) {
   
    int socket = *(int *)socket_desc;
    int read_size;
    
    char client_message[2000];

    printf("client conne %d\n",socket);
   
   
   
    while (( read_size =  recv( socket , client_message, 10000, 0) ) >= 1  ) {
      
        client_message[read_size] = '\0';
	
    
        int num  =  atoi(client_message);
        
        long long int result  =  factorial(num);

        char result_str[7000];
        
        
        sprintf(result_str, "%lld", result);

        write(socket, result_str, strlen(result_str));

        memset(client_message, 0, 7000);

    }

    if (read_size == 0) {
    
        puts("Client got Disconnected");
        
        fflush(stdout);
        
    } 
    
    else if (read_size == -1) {
        perror("recv failed");
    }

    
    close(socket);

    return 0;
}

int main(int argc, char *argv[]) {
    
    int  c;
    
    int socket_desc;
    
    int  client_sock ;
    
    struct sockaddr_in server, client;

    
    socket_desc = socket(AF_INET, SOCK_STREAM, 0);
    if (socket_desc == -1) {
        printf(" Socket Creation issue");
    }
    puts("Socket created");
    
    server.sin_port = htons(8888);

    
    server.sin_family = AF_INET;
    
    
    server.sin_addr.s_addr = INADDR_ANY;
    
    
    
    if (bind(socket_desc, (struct sockaddr *)&server, sizeof(server)) < 0) {
        
        perror("bind failed. Error");
        
        return 1;
        
    }
    puts("bind done");

    
    listen(socket_desc, 10000);

    
    printf("Waiting for incoming connections...");
    
    
    c = sizeof(struct sockaddr_in);

   
    
    pthread_t thread_id;
    
    int served_clients = 0;
    
    int max_clients = 4000;

    while (served_clients < max_clients) {
    
    
        client_sock = accept(socket_desc, (struct sockaddr *)&client, (socklen_t *)&c);
        
        
        if (client_sock < 0) {
        
           	 exit(1);
           	 
        }
	else if( client_sock >=0){
		printf("Connection accepted");

	}
        
        if (pthread_create(&thread_id, NULL, connection_handler, (void *)&client_sock) < 0) {
        
            perror("Thread wasnt created");
            
            close(client_sock);
            
            continue;
        }

        
        pthread_join(thread_id, NULL);
        served_clients = served_clients + 1 ;
        
        printf("Handler assigned");
    }

 
    close(socket_desc);

    return 0;
}



