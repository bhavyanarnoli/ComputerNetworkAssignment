#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <pthread.h>
#include <sys/select.h>
#include <sys/time.h>
#include <time.h>

#define PORT 5555

unsigned long long factorial(long long n){ 
    if( n > 20 ) {
        n = 20;
    }
    unsigned long long ans = 1;
    for (int i = 1; i <= n; i++){
        ans *= i;
    }
    return ans;
}

void check(int parameter1, const char* message_to_be_checked){
    if (parameter1 < 0){
        perror(message_to_be_checked);
        exit(1);
    }
}

int main(){
    int socket_fd;
    
    int bind_the_address;
    
    
    int new_socket;
    
      
    
    struct sockaddr_in serverAddr;
    struct sockaddr_in clienAddr;
    
       socklen_t addr_size;
    
    char factorial_of_number[101];


       pid_t pid;


    socket_fd = socket(AF_INET, SOCK_STREAM, 0);

           check(socket_fd, "Error in socket\n");


       memset(&serverAddr, '\0', sizeof(serverAddr));
    
       serverAddr.sin_family = AF_INET;
    
    
    
       serverAddr.sin_addr.s_addr = inet_addr("10.0.2.8");
    
       serverAddr.sin_port = htons(PORT);

           bind_the_address = bind(socket_fd, (struct sockaddr*)&serverAddr, sizeof(serverAddr));
      
    
    
        check(bind_the_address, "error in bind\n");

      if (listen(socket_fd, 10) < 0){
        perror("Error on listening\n");

}
    while (1){
    
    
    
        new_socket = accept( socket_fd, (struct sockaddr*)&clienAddr, &addr_size);
        
        if ( new_socket < 0){
            exit(1);
        }

        pid = fork();

        if (pid == 0){
            
            close(socket_fd);

            char *ip_address = inet_ntoa(clienAddr.sin_addr);
            
            
            int port_no = ntohs(clienAddr.sin_port);

            printf("Connection accepted from IP : %s: and PORT : %d\n", ip_address , port_no);

            while (1){
                bzero( factorial_of_number , 101 );
                
                
                int numbytes = recv(new_socket, &factorial_of_number, sizeof(factorial_of_number), 0);

                if (numbytes <= 0){
                    break;
                }

                long long num = atoi(factorial_of_number);
           
                sprintf( factorial_of_number , "%lld" , factorial(num) ); 
                
                send(new_socket, &factorial_of_number, sizeof(factorial_of_number), 0); 
                
            }

             close( new_socket );

            exit( 0 );
        }
        else if (pid < 0){
        
        
            perror("Process creation has been disrupted\n");
            
            
            exit(1);
        } 
         else{
           
            close(new_socket); 
        }
    }

 
    close(socket_fd);

    return 0;
}

