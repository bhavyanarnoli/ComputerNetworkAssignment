import matplotlib.pyplot as plt

from scapy.all import *


def calculate_congestion_window(timestamps, seq_numbers):
  
  congestion_window = [float('nan')]  
  for i in range(1, len(seq_numbers)):
    seq_diff = seq_numbers[i] - seq_numbers[i-1]
    
    time_diff = timestamps[i] - timestamps[i-1]
    if time_diff > 0:
      cwnd = seq_diff / time_diff  
    else:
      float('nan')
    
    congestion_window.append(-cwnd)

  return congestion_window

def extract_sequence_numbers(pcap_file):
  seq_numbers = []
  timestamps = []
  packets = rdpcap(pcap_file)

  for packet in packets:
    if 'TCP' in packet and 'IP' in packet:

      timestamps.append(packet.time)
      seq_numbers.append(packet[TCP].seq)

  return timestamps, seq_numbers


def plot_graph(timestamps, congestion_window):
  plt.plot(timestamps, congestion_window)
  plt.xlabel('Time (seconds)')
  plt.ylabel('Congestion Window Size')
  plt.title('Congestion Window Evolution Over Time')
  plt.show()

def main():
  pcap_file = 'bhavyacapture.pcap' 
  timestamps, seq_numbers = extract_sequence_numbers(pcap_file)
  congestion_window = calculate_congestion_window(timestamps, seq_numbers)
  plot_graph(timestamps, congestion_window)

if __name__ == "__main__":
  main()

