#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/epoll.h>

#define MAX_EVENTS 10

unsigned long long factorial(long long n){ 
    if( n > 20 ) {
        n = 20;
    }
    unsigned long long ans = 1;
    for (int i = 1; i <= n; i++){
        ans *= i;
    }
    return ans;
}

void *connection_handler(void *socket_desc) {
  
    int sock = *(int *)socket_desc;
    
    int read_size;
    
    char client_message[2000];

    
    while ((read_size = recv(sock, client_message, 10000, 0)) > 0) {
    
        client_message[read_size] = '\0';
    
        int num = atoi(client_message);
    
        long long int result = factorial(num);

    
        char result_str[7000];

        sprintf(result_str, "%lld", result);


        write(sock, result_str, strlen(result_str));

        memset(client_message, 0, 7000);

    }

    if (read_size == 0) {
        printf("Client disconnected");
        fflush(stdout);
    }
    else if (read_size < 0) {
        perror("recv failed");
    }

   
    close(sock);

    return 0;
}



int main(int argc, char *argv[]) {
    struct epoll_event ev;
    
    struct epoll_event events[MAX_EVENTS];
    int listen_sock;
    int conn_sock;
    int nfds;
    int  epollfd;

    // Create socket
    listen_sock = socket(AF_INET, SOCK_STREAM, 0);
    if (listen_sock == -1) {
        printf("Could not create socket");
    }
    puts("Socket created");

 
    struct sockaddr_in server, client;
    server.sin_family = AF_INET;
    server.sin_addr.s_addr = INADDR_ANY;
    server.sin_port = htons(5555);

   
    if (bind(listen_sock, (struct sockaddr *)&server, sizeof(server)) < 0) {
      
        perror("bind failed. Error");
        return 1;
    }
    puts("bind done");

    listen(listen_sock, 10000);


    puts("Waiting for incoming connections...");

    int c = sizeof(struct sockaddr_in);

    epollfd = epoll_create1(0);
    
    
    
    if (epollfd == -1) {

        perror("epoll_create1");
        exit(EXIT_FAILURE);
    }

    ev.events = EPOLLIN;
    ev.data.fd = listen_sock;
    if (epoll_ctl(epollfd, EPOLL_CTL_ADD, listen_sock, &ev) == -1) {
        perror("epoll_ctl: listen_sock");
        exit(EXIT_FAILURE);
    }

    for (;;) {
        nfds = epoll_wait(epollfd, events, MAX_EVENTS, -1);

        if (nfds == -1) {

            perror("epoll_wait");


            exit(EXIT_FAILURE);
        }

        for (int n = 0; n < nfds; ++n) {

            if (events[n].data.fd == listen_sock) {

                conn_sock = accept(listen_sock, (struct sockaddr *)&client, (socklen_t *)&c);
 	               if (conn_sock == -1) {
 	                   perror("accept");
 	                   exit(EXIT_FAILURE);
 	               }

 	               ev.events = EPOLLIN | EPOLLET;

 	               ev.data.fd = conn_sock;

 	               if (epoll_ctl(epollfd, EPOLL_CTL_ADD, conn_sock, &ev) == -1) {

 	                   perror("epoll_ctl: conn_sock");

 	                   exit(EXIT_FAILURE);
 	               }
 	           } 
 	      else {
 	               pthread_t thread_id;
                	  int *new_sock;
                	
                	new_sock = malloc(1);

                	*new_sock = events[n].data.fd;


               	    if (pthread_create(&thread_id, NULL, connection_handler, (void *)new_sock) < 0) {

                           perror("could not create thread");
                            return 1;

                		}
                pthread_join(thread_id, NULL);
            }
        }
    }

    return 0;
}


